# DevOps Internship Project — CI/CD for a Python (Flask) App

A fully automated CI/CD pipeline for a Dockerized Flask app using **GitHub Actions** for CI and **Jenkins** for CD, deploying to **AWS EC2** (optionally **Kubernetes**).

## Architecture

```text
GitHub (Code Push)
   ↓
GitHub Actions (CI: Lint + Test)
   ↓
Jenkins (CD: Build → Docker → Deploy)
   ↓
EC2 or Kubernetes (Running Flask App)
```

## Tech Stack
- Python Flask
- Docker
- GitHub Actions (CI)
- Jenkins (CD)
- AWS EC2 (or Kubernetes)
- Testing: pytest, flake8

## Local Setup
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python app.py
# open http://localhost:5000/
```

Or with Docker:
```bash
docker build -t flask-cicd-internship:latest .
docker run --rm -p 5000:5000 flask-cicd-internship:latest
```

## Endpoints
- `/` → `{ "message": "Hello from Flask CI/CD!" }`
- `/status` → `{ "status": "ok", "version": "1.0.0" }`
- `/healthz` → `{ "healthy": true }`

## GitHub Actions (CI)
- Lints with `flake8`
- Runs `pytest`
- Triggers on push and PR

## Jenkins (CD)
1. Create credentials:
   - `dockerhub-username` (username)
   - `dockerhub-password` (password/token)
   - `ec2-ssh-key` (SSH private key for EC2)
2. Update `EC2_HOST` in `Jenkinsfile` (or disable EC2 stage).
3. Optional: set `kubeconfig-file` secret file and flip the K8s stage condition to `true`.
4. Set webhook or keep `pollSCM` trigger.

## AWS EC2 Deploy (Option 1)
- Install Docker on EC2
- Ensure inbound security group allows HTTP (80)
- Jenkins will SSH and start the container mapping `80:5000`

## Kubernetes Deploy (Option 2)
- Edit `k8s/deployment.yaml` with your Docker Hub image
- `kubectl apply -f k8s/` (Jenkins stage provided)

## Project Scripts
- `Makefile` with common tasks
- `compose.yaml` for local container run

## How to Publish to GitHub
```bash
git init
git add .
git commit -m "Initial commit: Flask CI/CD pipeline"
git branch -M main
git remote add origin https://github.com/<your-username>/flask-cicd-internship.git
git push -u origin main
```

## Screenshots / Evidence (add your own)
- GitHub Actions run (passed)
- Jenkins pipeline stages (success)
- EC2 public URL / health check screenshot

---
_Internship deliverable prepared with parity to the brief._
